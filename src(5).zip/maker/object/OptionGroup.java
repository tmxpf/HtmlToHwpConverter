package maker.object;

public class OptionGroup {

	public static final String CLASS = "class";
	public static final String TYPE = "type";
	public static final String VALUE = "value";
	public static final String TEXT = "#text";
	public static final String STYLE = "style";
	
}

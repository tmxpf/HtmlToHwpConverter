package maker.object;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.nodes.Node;

public class TagOptions {

	private Node node;
	private String tagName;
	private String tagClass;
	private String tagType;
	private String tagValue;
	private String tagText;
	private Map<String, List<String>> tagStyles = new HashMap<String, List<String>>();
	
	public TagOptions(Node node) {
		this.node = node;
		
		initTagName();
		initOptions();
	}
	
	private void initTagName() {
		tagName = node.nodeName();
	}
	
	private void initOptions() {
		if(node.attributes().get(OptionGroup.CLASS) != null) {
			tagClass = node.attributes().get(OptionGroup.CLASS);
		}
		
		if(node.attributes().get(OptionGroup.TYPE) != null) {
			tagType = node.attributes().get(OptionGroup.TYPE);
		}
		
		if(node.attributes().get(OptionGroup.VALUE) != null) {
			tagValue = node.attributes().get(OptionGroup.VALUE);
		}
		
		if(node.attributes().get(OptionGroup.TEXT) != null) {
			tagText = node.attributes().get(OptionGroup.TEXT);
		}
		
		if(node.attributes().get(OptionGroup.STYLE) != null) {
			String[] styles = node.attributes().get(OptionGroup.STYLE).split(";");
			String[] cssOptions = null;
			
			for(String style : styles) {
				cssOptions = style.split(":");
			}
			
			for(int i = 0; i < cssOptions.length; i++) {
				if(i == 0) {
					tagStyles.put(cssOptions[i], new ArrayList<String>());
					continue;
				}
				
				tagStyles.get(cssOptions[0]).add(cssOptions[i]);
			}
		}
	}
	
	public String getTagName() {
		return tagName;
	}
	
	public String getTagClass() {
		return tagClass;
	}
	
	public String getTagType() {
		return tagType;
	}
	
	public String getTagValue() {
		return tagValue;
	}
	
	public String getTagText() {
		return tagText;
	}
	
	public Map<String, List<String>> getTagStyles() {
		return tagStyles;
	}
	
	public List<String> getTagStyle(String option) {
		return tagStyles.get(option);
	}
	
}

package maker;

public interface HwpContentMaker {

    public void make();

}

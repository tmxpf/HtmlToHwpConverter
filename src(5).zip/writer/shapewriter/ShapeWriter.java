package writer.shapewriter;

public class ShapeWriter {

}

package writer.shapewriter;

public class ShapeMaker {

}

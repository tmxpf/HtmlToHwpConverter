package parser.htmlparser;

import org.jsoup.nodes.Node;
import org.jsoup.select.NodeVisitor;

public class NodeTreeSearch implements NodeVisitor{

	@Override
	public void head(Node node, int depth) {
		node.attributes();
		node.nodeName();
	}

	@Override
	public void tail(Node node, int depth) {
		
	}

}
